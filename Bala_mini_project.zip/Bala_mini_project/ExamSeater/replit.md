# Exam Hall Allotment and Seating Arrangement System

## Overview
A comprehensive web application that automates the process of assigning exam halls and generating seating arrangements for students. The system ensures fair seating by preventing students from the same department from sitting adjacent to each other.

## Current State
The application is fully functional with all core features implemented:
- ✅ Student registration (manual and CSV upload)
- ✅ Room allocation management
- ✅ Smart seating algorithm
- ✅ Visual seating layout (grid view)
- ✅ Search functionality
- ✅ PDF export

## Tech Stack

### Backend
- **Python 3.11** - Programming language
- **Flask** - Web framework
- **Werkzeug** - WSGI utility library
- **JSON file storage** - Data persistence (development)

### Frontend
- **HTML5, CSS3, JavaScript** - Core web technologies
- **Bootstrap 5** - Responsive UI framework
- **PapaParse** - CSV parsing library
- **jsPDF** - PDF generation library

## Project Architecture

### Directory Structure
```
.
├── app.py                 # Main Flask application
├── templates/             # HTML templates
│   ├── index.html        # Student registration page
│   ├── rooms.html        # Room allocation page
│   └── seating.html      # Seating arrangement page
├── static/               # Static assets
│   ├── css/
│   │   └── style.css     # Custom styles
│   └── js/
│       ├── main.js       # Student registration logic
│       ├── rooms.js      # Room allocation logic
│       └── seating.js    # Seating arrangement & search
├── data/                 # JSON data storage
│   ├── students.json
│   ├── rooms.json
│   └── allocation.json
└── sample_students.csv   # Sample data for testing
```

### Key Features

#### 1. Student Registration
- **Manual Entry**: Add students individually with name, register number, and department
- **CSV Upload**: Bulk import students from CSV files
- **Data Management**: View all registered students and clear data when needed

#### 2. Room Allocation
- **Dynamic Room Management**: Add multiple rooms with custom capacity
- **Capacity Tracking**: Real-time display of total capacity vs. registered students
- **Validation**: Ensures sufficient room capacity before generating seating

#### 3. Smart Seating Algorithm
The seating algorithm uses a priority queue (max-heap) approach:
- Groups students by department
- Uses a max-heap to prioritize departments with the most remaining students
- Ensures no two adjacent seats have students from the same department (when possible)
- When only one department remains, places those students together (unavoidable)
- Minimizes same-department adjacency even with imbalanced department sizes

#### 4. Visual Seating Layout
- **Grid View**: Top-down view of each room's seating arrangement
- **Color-Coded Seats**: 
  - Blue: Occupied seats with student info
  - Gray: Empty seats
- **Hover Details**: Shows full student information on hover
- **Room-by-Room Display**: Organized layout for each exam hall

#### 5. Search Functionality
- **Real-time Search**: Instant results as you type
- **Dual Search**: Find by student name or register number
- **Detailed Results**: Shows name, register number, department, room, and seat number

#### 6. PDF Export
- **Printable Format**: Generate PDF of complete seating arrangement
- **Room Organization**: Lists all students by room and seat number
- **Department Information**: Includes department for easy verification

## How to Use

### 1. Student Registration
1. Navigate to the home page
2. Choose between manual entry or CSV upload
3. For CSV: Use the format `Name, Register Number, Department`
4. Click "Proceed to Room Allocation" when done

### 2. Room Allocation
1. Enter room number and seat capacity
2. Add multiple rooms as needed
3. Ensure total capacity ≥ number of students
4. Click "Generate Seating Arrangement"

### 3. View Seating
1. Search for specific students using the search bar
2. View the complete seating layout for all rooms
3. Export as PDF for printing or sharing

## Sample CSV Format
```csv
Name,Register Number,Department
John Doe,CS2024001,CSE
Jane Smith,EC2024001,ECE
Michael Brown,ME2024001,MECH
```

A sample CSV file (`sample_students.csv`) is included in the project.

## Running the Application
The Flask server runs on port 5000 and is configured to accept connections from all hosts.

```bash
python app.py
```

Access the application at: `http://0.0.0.0:5000`

## Data Storage
Currently using JSON file-based storage:
- `data/students.json` - Student records
- `data/rooms.json` - Room configurations
- `data/allocation.json` - Seating arrangements

## Future Enhancements (Next Phase)
1. **Database Integration**: MongoDB for persistent storage
2. **Front View Layout**: Alternative classroom-style visualization
3. **Exam Scheduling**: Support multiple exam sessions
4. **Admin Dashboard**: Analytics and historical records
5. **Manual Override**: Ability to manually adjust seat assignments
6. **Authentication**: Admin login and access control
7. **Export Options**: Excel/CSV export in addition to PDF

## Recent Changes
- **October 14, 2025**: Initial project setup and MVP implementation
  - Created Flask backend with RESTful API
  - Implemented all frontend pages with Bootstrap
  - Developed smart seating algorithm
  - Added CSV upload and PDF export features
  - Set up development workflow

## Development Notes
- The application uses file-based JSON storage for the MVP
- All frontend assets are served from the `static/` directory
- The workflow is configured to run on port 5000
- Bootstrap CDN is used for styling
- PapaParse and jsPDF are loaded via CDN
