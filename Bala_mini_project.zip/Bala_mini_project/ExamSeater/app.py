from flask import Flask, render_template, request, jsonify, send_file
import json
import os
from werkzeug.utils import secure_filename
from datetime import datetime
import csv
from io import StringIO

app = Flask(__name__)
app.config['SECRET_KEY'] = os.environ.get('SESSION_SECRET', 'dev-secret-key')
app.config['UPLOAD_FOLDER'] = 'uploads'
app.config['MAX_CONTENT_LENGTH'] = 16 * 1024 * 1024

DATA_DIR = 'data'
STUDENTS_FILE = os.path.join(DATA_DIR, 'students.json')
ROOMS_FILE = os.path.join(DATA_DIR, 'rooms.json')
ALLOCATION_FILE = os.path.join(DATA_DIR, 'allocation.json')

os.makedirs(DATA_DIR, exist_ok=True)
os.makedirs(app.config['UPLOAD_FOLDER'], exist_ok=True)

def load_json(filepath, default=None):
    if os.path.exists(filepath):
        with open(filepath, 'r') as f:
            return json.load(f)
    return default if default is not None else []

def save_json(filepath, data):
    with open(filepath, 'w') as f:
        json.dump(data, f, indent=2)

@app.route('/')
def index():
    return render_template('index.html')

@app.route('/rooms')
def rooms():
    return render_template('rooms.html')

@app.route('/seating')
def seating():
    return render_template('seating.html')

@app.route('/api/students', methods=['GET', 'POST', 'DELETE'])
def handle_students():
    if request.method == 'GET':
        students = load_json(STUDENTS_FILE, [])
        return jsonify(students)
    
    elif request.method == 'POST':
        data = request.json or {}
        students = load_json(STUDENTS_FILE, [])
        
        if 'bulk' in data:
            students.extend(data.get('students', []))
        else:
            students.append({
                'name': data.get('name', ''),
                'registerNumber': data.get('registerNumber', ''),
                'department': data.get('department', '')
            })
        
        save_json(STUDENTS_FILE, students)
        return jsonify({'success': True, 'count': len(students)})
    
    elif request.method == 'DELETE':
        save_json(STUDENTS_FILE, [])
        save_json(ALLOCATION_FILE, {})
        return jsonify({'success': True})
    
    return jsonify({'error': 'Invalid method'}), 405

@app.route('/api/rooms', methods=['GET', 'POST', 'DELETE'])
def handle_rooms():
    if request.method == 'GET':
        rooms = load_json(ROOMS_FILE, [])
        return jsonify(rooms)
    
    elif request.method == 'POST':
        data = request.json or {}
        rooms = load_json(ROOMS_FILE, [])
        rooms.append({
            'roomNumber': data.get('roomNumber', ''),
            'capacity': int(data.get('capacity', 0))
        })
        save_json(ROOMS_FILE, rooms)
        return jsonify({'success': True})
    
    elif request.method == 'DELETE':
        save_json(ROOMS_FILE, [])
        save_json(ALLOCATION_FILE, {})
        return jsonify({'success': True})
    
    return jsonify({'error': 'Invalid method'}), 405

@app.route('/api/allocate', methods=['POST'])
def allocate_seats():
    students = load_json(STUDENTS_FILE, [])
    rooms = load_json(ROOMS_FILE, [])
    
    if not students or not rooms:
        return jsonify({'success': False, 'error': 'No students or rooms data'}), 400
    
    total_capacity = sum(room['capacity'] for room in rooms)
    if len(students) > total_capacity:
        return jsonify({'success': False, 'error': 'Not enough room capacity'}), 400
    
    allocation = allocate_students_to_rooms(students, rooms)
    save_json(ALLOCATION_FILE, allocation)
    
    return jsonify({'success': True, 'allocation': allocation})

def allocate_students_to_rooms(students, rooms):
    from collections import defaultdict
    import heapq
    
    dept_groups = defaultdict(list)
    for student in students:
        dept_groups[student['department']].append(student)
    
    allocation = {}
    for room in rooms:
        room_number = room['roomNumber']
        capacity = room['capacity']
        allocation[room_number] = {
            'capacity': capacity,
            'seats': []
        }
    
    heap = [(-len(students_list), dept, students_list) for dept, students_list in dept_groups.items()]
    heapq.heapify(heap)
    
    assigned_students = []
    last_dept = None
    
    while heap:
        candidates = []
        found = False
        
        while heap and not found:
            neg_count, dept, students_list = heapq.heappop(heap)
            
            if dept != last_dept:
                student = students_list.pop(0)
                assigned_students.append(student)
                last_dept = dept
                found = True
                
                if students_list:
                    heapq.heappush(heap, (-len(students_list), dept, students_list))
            else:
                candidates.append((neg_count, dept, students_list))
        
        if not found and candidates:
            neg_count, dept, students_list = candidates[0]
            student = students_list.pop(0)
            assigned_students.append(student)
            last_dept = dept
            
            if students_list:
                heapq.heappush(heap, (-len(students_list), dept, students_list))
            
            for item in candidates[1:]:
                heapq.heappush(heap, item)
        else:
            for item in candidates:
                heapq.heappush(heap, item)
    
    student_idx = 0
    for room in rooms:
        room_number = room['roomNumber']
        capacity = room['capacity']
        
        for seat_num in range(1, capacity + 1):
            if student_idx < len(assigned_students):
                allocation[room_number]['seats'].append({
                    'seatNumber': seat_num,
                    'student': assigned_students[student_idx]
                })
                student_idx += 1
            else:
                allocation[room_number]['seats'].append({
                    'seatNumber': seat_num,
                    'student': None
                })
    
    return allocation

@app.route('/api/allocation', methods=['GET'])
def get_allocation():
    allocation = load_json(ALLOCATION_FILE, {})
    return jsonify(allocation)

@app.route('/api/search', methods=['GET'])
def search_student():
    query = request.args.get('q', '').strip().lower()
    if not query:
        return jsonify({'results': []})
    
    allocation = load_json(ALLOCATION_FILE, {})
    if isinstance(allocation, list):
        allocation = {}
    results = []
    
    for room_number, room_data in allocation.items():
        for seat in room_data['seats']:
            if seat['student']:
                student = seat['student']
                if (query in student['name'].lower() or 
                    query in student['registerNumber'].lower()):
                    results.append({
                        'name': student['name'],
                        'registerNumber': student['registerNumber'],
                        'department': student['department'],
                        'roomNumber': room_number,
                        'seatNumber': seat['seatNumber']
                    })
    
    return jsonify({'results': results})

if __name__ == '__main__':
    app.run(host='0.0.0.0', port=5000, debug=True)
