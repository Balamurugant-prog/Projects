let allocationData = null;

document.addEventListener('DOMContentLoaded', function() {
    loadSeatingArrangement();

    let searchTimeout;
    document.getElementById('searchStudent').addEventListener('input', function(e) {
        clearTimeout(searchTimeout);
        searchTimeout = setTimeout(() => {
            searchStudents(e.target.value);
        }, 300);
    });

    document.getElementById('exportPDF').addEventListener('click', exportToPDF);
});

async function loadSeatingArrangement() {
    const response = await fetch('/api/allocation');
    allocationData = await response.json();

    const layoutDiv = document.getElementById('seatingLayout');
    layoutDiv.innerHTML = '';

    for (const [roomNumber, roomData] of Object.entries(allocationData)) {
        const roomSection = document.createElement('div');
        roomSection.className = 'room-section';
        
        const occupiedSeats = roomData.seats.filter(s => s.student !== null).length;
        
        roomSection.innerHTML = `
            <div class="room-header">
                <h5>Room: ${roomNumber}</h5>
                <p class="mb-0">Capacity: ${roomData.capacity} | Occupied: ${occupiedSeats}</p>
            </div>
            <div class="seating-grid" id="room-${roomNumber}"></div>
        `;
        
        layoutDiv.appendChild(roomSection);

        const gridDiv = document.getElementById(`room-${roomNumber}`);
        
        roomData.seats.forEach(seat => {
            const seatDiv = document.createElement('div');
            seatDiv.className = 'seat';
            
            if (seat.student) {
                seatDiv.classList.add('occupied');
                seatDiv.innerHTML = `
                    <div class="seat-info">
                        <div><strong>${seat.seatNumber}</strong></div>
                        <div>${seat.student.registerNumber}</div>
                        <div class="department-badge bg-light text-dark">${seat.student.department}</div>
                    </div>
                `;
                seatDiv.title = `${seat.student.name} (${seat.student.registerNumber})`;
            } else {
                seatDiv.classList.add('empty');
                seatDiv.innerHTML = `<div>${seat.seatNumber}</div>`;
            }
            
            gridDiv.appendChild(seatDiv);
        });
    }
}

async function searchStudents(query) {
    if (!query.trim()) {
        document.getElementById('searchResults').innerHTML = '';
        return;
    }

    const response = await fetch(`/api/search?q=${encodeURIComponent(query)}`);
    const data = await response.json();

    const resultsDiv = document.getElementById('searchResults');
    
    if (data.results.length === 0) {
        resultsDiv.innerHTML = '<div class="alert alert-warning">No students found</div>';
        return;
    }

    resultsDiv.innerHTML = data.results.map(result => `
        <div class="search-result">
            <strong>${result.name}</strong> (${result.registerNumber})<br>
            <small>Department: ${result.department} | Room: ${result.roomNumber} | Seat: ${result.seatNumber}</small>
        </div>
    `).join('');
}

function exportToPDF() {
    const { jsPDF } = window.jspdf;
    const doc = new jsPDF();
    
    let yPosition = 20;
    
    doc.setFontSize(18);
    doc.text('Exam Hall Seating Arrangement', 105, yPosition, { align: 'center' });
    yPosition += 15;

    doc.setFontSize(10);

    for (const [roomNumber, roomData] of Object.entries(allocationData)) {
        if (yPosition > 270) {
            doc.addPage();
            yPosition = 20;
        }

        doc.setFontSize(14);
        doc.text(`Room: ${roomNumber}`, 20, yPosition);
        yPosition += 10;

        doc.setFontSize(10);
        const occupiedSeats = roomData.seats.filter(s => s.student !== null);
        
        occupiedSeats.forEach((seat, index) => {
            if (seat.student) {
                const text = `Seat ${seat.seatNumber}: ${seat.student.name} (${seat.student.registerNumber}) - ${seat.student.department}`;
                
                if (yPosition > 270) {
                    doc.addPage();
                    yPosition = 20;
                }
                
                doc.text(text, 25, yPosition);
                yPosition += 7;
            }
        });

        yPosition += 10;
    }

    doc.save('seating-arrangement.pdf');
}
