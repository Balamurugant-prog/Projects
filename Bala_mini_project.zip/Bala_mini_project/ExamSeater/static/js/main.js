document.addEventListener('DOMContentLoaded', function() {
    loadStudents();

    document.getElementById('studentForm').addEventListener('submit', async function(e) {
        e.preventDefault();
        
        const name = document.getElementById('name').value;
        const registerNumber = document.getElementById('registerNumber').value;
        const department = document.getElementById('department').value;

        const response = await fetch('/api/students', {
            method: 'POST',
            headers: {'Content-Type': 'application/json'},
            body: JSON.stringify({ name, registerNumber, department })
        });

        if (response.ok) {
            document.getElementById('studentForm').reset();
            loadStudents();
        }
    });

    document.getElementById('uploadCSV').addEventListener('click', async function() {
        const fileInput = document.getElementById('csvFile');
        const file = fileInput.files[0];

        if (!file) {
            alert('Please select a CSV file');
            return;
        }

        Papa.parse(file, {
            header: true,
            complete: async function(results) {
                const students = results.data
                    .filter(row => row['Name'] && row['Register Number'] && row['Department'])
                    .map(row => ({
                        name: row['Name'],
                        registerNumber: row['Register Number'],
                        department: row['Department']
                    }));

                if (students.length === 0) {
                    alert('No valid student data found in CSV');
                    return;
                }

                const response = await fetch('/api/students', {
                    method: 'POST',
                    headers: {'Content-Type': 'application/json'},
                    body: JSON.stringify({ bulk: true, students })
                });

                if (response.ok) {
                    fileInput.value = '';
                    loadStudents();
                    alert(`${students.length} students added successfully!`);
                }
            }
        });
    });

    document.getElementById('clearStudents').addEventListener('click', async function() {
        if (confirm('Are you sure you want to clear all students?')) {
            await fetch('/api/students', { method: 'DELETE' });
            loadStudents();
        }
    });

    document.getElementById('proceedToRooms').addEventListener('click', function() {
        window.location.href = '/rooms';
    });
});

async function loadStudents() {
    const response = await fetch('/api/students');
    const students = await response.json();

    document.getElementById('studentCount').textContent = students.length;
    
    const tbody = document.getElementById('studentTableBody');
    tbody.innerHTML = '';

    students.forEach(student => {
        const row = tbody.insertRow();
        row.innerHTML = `
            <td>${student.name}</td>
            <td>${student.registerNumber}</td>
            <td><span class="badge bg-info">${student.department}</span></td>
        `;
    });
}
