document.addEventListener('DOMContentLoaded', function() {
    loadRooms();
    loadStudentCount();

    document.getElementById('roomForm').addEventListener('submit', async function(e) {
        e.preventDefault();
        
        const roomNumber = document.getElementById('roomNumber').value;
        const capacity = document.getElementById('capacity').value;

        const response = await fetch('/api/rooms', {
            method: 'POST',
            headers: {'Content-Type': 'application/json'},
            body: JSON.stringify({ roomNumber, capacity })
        });

        if (response.ok) {
            document.getElementById('roomForm').reset();
            loadRooms();
        }
    });

    document.getElementById('generateSeating').addEventListener('click', async function() {
        const response = await fetch('/api/allocate', {
            method: 'POST',
            headers: {'Content-Type': 'application/json'}
        });

        const result = await response.json();

        if (result.success) {
            window.location.href = '/seating';
        } else {
            alert('Error: ' + result.error);
        }
    });
});

async function loadRooms() {
    const response = await fetch('/api/rooms');
    const rooms = await response.json();

    document.getElementById('roomCount').textContent = rooms.length;
    
    const totalCapacity = rooms.reduce((sum, room) => sum + room.capacity, 0);
    document.getElementById('totalCapacity').textContent = totalCapacity;
    
    const tbody = document.getElementById('roomTableBody');
    tbody.innerHTML = '';

    rooms.forEach(room => {
        const row = tbody.insertRow();
        row.innerHTML = `
            <td>${room.roomNumber}</td>
            <td>${room.capacity}</td>
            <td><button class="btn btn-sm btn-danger" onclick="deleteRoom('${room.roomNumber}')">Delete</button></td>
        `;
    });
}

async function loadStudentCount() {
    const response = await fetch('/api/students');
    const students = await response.json();
    document.getElementById('totalStudents').textContent = students.length;
}

async function deleteRoom(roomNumber) {
    if (confirm('Delete this room?')) {
        const response = await fetch('/api/rooms');
        const rooms = await response.json();
        const updatedRooms = rooms.filter(r => r.roomNumber !== roomNumber);
        
        await fetch('/api/rooms', { method: 'DELETE' });
        
        for (const room of updatedRooms) {
            await fetch('/api/rooms', {
                method: 'POST',
                headers: {'Content-Type': 'application/json'},
                body: JSON.stringify(room)
            });
        }
        
        loadRooms();
    }
}
